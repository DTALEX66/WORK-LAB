"""Read back only the declared rule write set; never run agents or read secrets."""
from pathlib import Path
import hashlib
import json
import importlib.util

ROOT = Path(__file__).resolve().parent
checks = []


def read(name):
    return json.loads((ROOT / 'evidence' / name).read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(name, condition):
    checks.append({'check': name, 'status': 'PASS' if condition else 'FAIL'})


core = (ROOT / 'AGENT_CORE.md').read_text(encoding='utf-8-sig').strip()
rows = read('deployment.json')['files'] + read('expanded-deployment.json')['files']
hermes = read('hermes-deployment.json')
rows += [{'path': hermes['target'], 'after_sha256': hermes['after_sha256']}]
check('unique_live_targets_21', len(rows) == 21 and len({a['path'].casefold() for a in rows}) == 21)
for row in rows:
    path = Path(row['path'])
    assert 'archeaxis' not in str(path).casefold()
    assert path.drive.upper() not in ('E:', 'F:')
    check(str(path)+':safe_path', not any(p.is_symlink() or p.is_junction() for p in [path, *path.parents]) and path.stat().st_nlink == 1)
    check(str(path)+':after_hash', sha(path) == row['after_sha256'])
    text = path.read_text(encoding='utf-8-sig')
    check(str(path)+':core_once', text.count(core) == 1)
    check(str(path)+':markers_once', text.count('## BEGIN UNIVERSAL_AGENT_CORE v1.0.0') == text.count('## END UNIVERSAL_AGENT_CORE v1.0.0') == 1)
for receipt in ['deployment.json', 'expanded-deployment-phase1.json', 'expanded-deployment-phase2.json', 'expanded-deployment.json', 'hermes-source-preparation.json', 'source-convergence.json']:
    for item in read(receipt)['files']:
        if item.get('backup'):
            check(receipt+':backup:'+Path(item['backup']).name, sha(item['backup']) == item['before_sha256'])
check('hermes_source_matches_live', sha(hermes['source']) == sha(hermes['target']))
check('hermes_only_soul_other_assets_preserved', hermes['only_written_asset'] == 'SOUL.md' and hermes['all_other_managed_asset_digests_preserved'] and hermes['persistent_suspension_preserved'])
for item in read('source-convergence.json')['files']:
    check('source_after:'+item['path'], sha(item['path']) == item['after_sha256'])
for item in read('source-convergence.json')['new_files']:
    check('new_source:'+item['path'], sha(item['path']) == item['sha256'])
spec = importlib.util.spec_from_file_location('expanded_rules', ROOT / 'deploy_expanded_rules.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
check('expanded_current_plan_noop', all(a['operation'] == 'NOOP' for a in module.plan()['files']))
inv = read('project-rule-inventory.json')
for project in inv:
    if not project['git'] or 'archeaxis' in project['root'].casefold():
        continue
    for item in project['rule_files']:
        check('original_project_rule_preserved:'+project['root']+'/'+item['file'], sha(Path(project['root'])/item['file']) == item['sha256'])
for name in ['codex-context-check.json', 'hermes-native-loader.json', 'dsh-native-loader.json', 'minimax-native-loader.json']:
    check('native_diagnostic:'+name, read(name)['status'] == 'PASS')
check('source_local_regressions', read('source-convergence-tests.json')['exit_code'] == 0)
check('codex_native_personal_plan_noop', read('codex-personal-native-plan.json')['write_set_count'] == 0)
check('open_design_honestly_blocked', read('open-design-native-cli.json')['status'] == 'BLOCKED')
result = {'status': 'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL',
          'checks': checks, 'total': len(checks), 'failed': sum(c['status']=='FAIL' for c in checks),
          'live_rule_files': len(rows), 'native_no_model_diagnostics': 4,
          'fresh_agent_sessions': 'NOT_EXECUTED', 'behavior': 'NOT_EXECUTED',
          'scope': 'Declared files, backup integrity, local regression and native loader diagnostics; no blanket runtime acceptance'}
(ROOT/'evidence/expanded-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}, ensure_ascii=False))
raise SystemExit(1 if result['failed'] else 0)
