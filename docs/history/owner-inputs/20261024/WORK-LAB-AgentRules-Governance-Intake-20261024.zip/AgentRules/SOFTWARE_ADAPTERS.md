# 软件适配入口与核对线索

编制日期：2026-10-23。以下是当前官方文档线索，不是本机安装或兼容性证明；应用前核对实际版本、模式、配置根目录及已有文件。

| 软件或模式 | 核对入口 | 实施注意事项 |
| --- | --- | --- |
| Codex 本地 | 当前 Codex home 下的 `AGENTS.md` | 默认 `~/.codex`，核对 `CODEX_HOME`；同目录 `AGENTS.override.md` 可能使基础文件不被读取。不要未经分析删除覆盖文件。 |
| Claude Code | `~/.claude/CLAUDE.md` 用户指令 | 项目 `AGENTS.md` 是否加载受版本、项目 CLAUDE 文件与配置影响；不要盲目同时添加两份相同正文。 |
| Claude 桌面 Cowork | 实际模式支持的规则入口 | 官方说明用户级工作目录外导入、部分链接可能被跳过；不能把 Claude Code 的外部导入方案直接推广到 Cowork。 |
| Cursor Agent Chat | Customize → Rules 中的 User Rules | 具体安装版本为准；官方当前说明 User Rules 不适用于 Tab 和 Inline Edit，不写“全功能覆盖”。 |
| Gemini CLI | `~/.gemini/GEMINI.md` | 核对实际用户目录及文件名配置；可通过原生 memory 功能查看加载内容。不要据此假定 Gemini 网页端也读取本机文件。 |
| 网页型 AI 产品 | 实际可用的个性化、项目或专用 Agent 指令 | 按界面支持的范围和长度生成文本，不擅自操作内部数据库或猜测配置路径。 |
| 设计、媒体及自动化 Agent | 该产品当前官方支持的 Agent instructions、项目规则或工作流节点指令 | 无持久入口时提供任务启动文本；没有原生控制的功能标记为不支持，不伪装“全局已生效”。 |

## 分发方式

1. 母版集中维护。给已确认入口同步精简正文；针对只接受文本的设置生成可直接粘贴的版本。
2. 优先使用受支持且经过验证的机制。原生导入适用时可以用；否则同步实体正文。不要默认软链接、远程 URL 或一句“读取这个文件”在所有模式下有效。
3. 不覆盖用户已有规则。备份后合并；仅管理清楚标记的区段，不写重复正文，不自行放宽边界。后续发现人工改动时先核对，不能强制覆盖。
4. 按实际官方语义处理规则优先级和覆盖关系，不为所有软件编造同一优先级。禁止改写或替换平台自带 system prompt 以强行提升规则优先级。
5. 对精确规则入口的写入属于本次任务书授权；权限控制、鉴权、模型、服务商、后台服务和软件升级不在授权范围内。

## 验证记录

每个软件和模式分别记录：实际版本、目标入口、母版版本/摘要、旧文件备份位置、改动区段、加载证据、行为检查结果、未覆盖范围和回退方法。文件存在不代表规则加载；Agent 自述只是辅助证据，优先原生上下文查看或诊断结果。

## 官方来源

- [Codex AGENTS.md](https://learn.chatgpt.com/docs/agent-configuration/agents-md)
- [Windows Agent 运行环境](https://learn.chatgpt.com/docs/app/windows)
- [Claude Code 指令与记忆](https://code.claude.com/docs/en/memory)
- [Cursor Rules](https://cursor.com/docs/rules)
- [Gemini CLI GEMINI.md](https://geminicli.com/docs/cli/gemini-md/)

参考链接不是操作授权。新版本有差异时，以对应版本的实际行为和当前官方文档修正适配说明；保留通用核心含义。
