# 跨软件 Agent 规则部署报告

更新时间：2026-10-23（Asia/Shanghai）

## 交付结论

按用户最新授权，已执行 AAOS 以外可确认的规则配置：**11 类软件/Agent 产品入口，共 21 个原生规则文件**；其中 11 个用户级文件，10 个项目级文件，项目级覆盖五个非 AAOS Git 项目。CodeBuddy 的 CLI 与 IDE 分别适配；WorkBuddy 的默认和现存个人 SOUL 分别保留。

- 配置写入与摘要回读：21/21 PASS。
- 原生无模型加载诊断：Codex、Hermes、DSH、MiniMax Code，4 项 PASS。
- 全新 Agent 会话启动加载：UNVERIFIED；行为验收：NOT_EXECUTED。没有发起额外付费或模型会话。
- 本地规则投影/同步回归：51 项 PASS。声明写入集的只读核验：159 项 PASS；原任务包基础核验：28 项 PASS。它们有重叠，不能合计成独立功能测试数量。
- 未完成：Open Design 服务接口当前不可用；MiniMax Design 全局持久入口尚未确认；Claude 普通 Chat 等账户界面规则、Cursor 在其他未来项目的全局规则，以及各软件新会话验收，见 [MANUAL_STEPS.md](C:/Users/ALEX/AgentRules/MANUAL_STEPS.md)。

AAOS 项目内文件没有写入；修复交接单独保留在 [AAOS_RULES_REPAIR_HANDOFF.md](C:/Users/ALEX/AgentRules/AAOS_RULES_REPAIR_HANDOFF.md)。本机用户级规则的生效范围可能包含以后打开的 AAOS 会话，这不等于修改 AAOS 项目。

## 依据、范围和母版

先前已读取 START_HERE.md、LOCAL_CODEX_TASK.md、AGENT_CORE.md、WORKFLOW_MODULES.md、SOFTWARE_ADAPTERS.md。后续聊天中“AAOS 项目只改自己的项目，你继续负责其他的”“除了 AAOS 你不能全部执行吗”扩展了原任务书的文件入口与项目写入范围。已完成项目规则和必要同步源衔接；保留原来的模型、鉴权、权限、安装、付费调用及登录界面边界。

唯一通用正文母版：[AGENT_CORE.md](C:/Users/ALEX/AgentRules/AGENT_CORE.md)，版本 1.0.0，SHA-256：`e180ea6cff9cceba7009cfc717debcf3de335b911c65c9265cb744d704b7b38a`。五个原始输入文件均与 SHA256SUMS.txt 一致，未改写。所有新入口采用可见管理区段，全文出现一次；没有依靠普通路径链接来代替核心正文。

发现过程只检查注册安装信息、已知软件安装目录/原生代码、命令帮助、D:/All projects 的一级项目标记和明确规则文件；没有全盘或整 Home 扫描。未进入 WSL、远程、云端环境；没有读取私人 session、浏览器数据库或鉴权文件。E/F 未访问；没有修改模型、provider、reasoning、端点、权限和系统环境变量，没有安装、升级、提交、推送或创建常驻同步服务。

本报告中的“PASS 原生诊断”指调用已安装版本的具体加载函数/上下文构建工具；“启动已加载”专指真实新 Agent 会话。文件存在、正文回读、函数诊断、行为符合要求分别记录。

## 软件适配与实际结果

以下全部写入入口均为母版 1.0.0；行为列统一为 NOT_EXECUTED。

| 软件、实际版本/模式 | 实际写入入口 | 写入 | 加载证据及限制 |
| --- | --- | --- | --- |
| Codex Desktop 26.1016.8622.0；CLI 0.163.0-alpha.11.2，本地 | `C:/Users/ALEX/.codex/AGENTS.md` | PASS | 已安装 CLI 的 `debug prompt-input` 退出 0，完整母版一次；原生 personal-guidance 计划 NOOP。新桌面/CLI Agent 会话 UNVERIFIED；其他 CODEX_HOME、云端/远程未覆盖 |
| Claude Desktop 2.42304.0.0 中的本地 Code 规则候选 | `C:/Users/ALEX/.claude/CLAUDE.md` | PASS | 保留软件补充；PATH 未发现独立 Claude Code CLI，内嵌版本与实际加载 UNVERIFIED。普通 Chat 的账户设置、Cowork 的目录权限和加载单独验证 |
| Hermes v0.22.2（2026.9.24），git d923a5eb487a | `C:/Users/ALEX/AppData/Local/hermes/SOUL.md` | PASS | 经现有受管同步器发布；原生 `load_soul_md` 读到母版一次，PASS；新 Agent 会话 UNVERIFIED |
| DeepSeek Harness 0.2.1-rc.2 | `C:/Users/ALEX/.dsh/AGENTS.md` | PASS | 安装包 `@deepseek-ai/dsh-agent-instructions` 的 `loadBaselineInstructions` 返回正文，母版一次，PASS；具体运行 profile 仍须确认未关闭该插件 |
| CodeBuddy Code CLI 2.167.0 | `C:/Users/ALEX/.codebuddy/CODEBUDDY.md` | PASS | 官方 CLI 用户规则入口；实际新会话加载 UNVERIFIED；不据此认定 IDE 已加载 |
| CodeBuddy CN IDE 注册版本 1.106.1，内置 coding-copilot 3.10.0 | 五项目 `.codebuddy/rules/universal-agent-core/RULE.mdc` | PASS | 官方 IDE 格式，`alwaysApply: true`、`enabled: true`；新会话加载 UNVERIFIED |
| Cursor 3.24.12，commit 37b865941ccb31e2fc90c685157534efca87f960 | 五项目 `.cursor/rules/universal-agent-core.mdc` | PASS | 原生 MDC，`alwaysApply: true`；项目外的 User Rules 为 GUI 入口，本轮未写；实际加载 UNVERIFIED |
| WorkBuddy 5.8.3，本地标准/专家 identity 收集器 | `C:/Users/ALEX/.workbuddy/SOUL.md`；现存 personal 目录内 `SOUL.md`，完整路径见下方清单 | PASS | 安装版 IdentityCollector 读取 SOUL；原始 persona/frontmatter 保留，长度低于其 10000 字符预算。当前账户选择和新会话加载 UNVERIFIED；其他云端模式不据此宣称覆盖 |
| TRAE CN 3.4.4 | `C:/Users/ALEX/.trae-cn/user_rules.md` | PASS | 已安装 workbench 同时兼容单文件/多文件规则模式，因此选择二者都能发现的旧式单文件入口；实际当前模式加载 UNVERIFIED；未另建多文件副本重复注入 |
| Qoder CN 0.4.11；CN SDK 1.0.56-alpha.6；worker 1.1.75-hotfix.1 | `C:/Users/ALEX/.qoder-cn/AGENTS.md` | PASS | 本机安装的是 Agent workbench；CN worker 的原生 global-config 路径已核实，不能套用通用 `.qoder` 或 Qoder IDE 路径。未启动 worker 的认证初始化，加载 UNVERIFIED；未宣称当前正在运行 0.4.11 |
| MiniMax Code 3.1.4，本地 local-runtime-v2 | `C:/Users/ALEX/.minimax/AGENTS.md` | PASS | 直接调用已安装 `GlobalInstructions.readForPrompt`，母版一次，PASS；实际新任务/自定义数据目录配置仍需验证 |
| VS Code 1.131.0，内置 GitHub copilot-chat 0.59.0 | `C:/Users/ALEX/.copilot/instructions/universal-agent-core.instructions.md` | PASS | 安装版 workbench 默认用户目录明确包含 `~/.copilot/instructions`；`applyTo: "**"`。不依赖用户 profile 私有设置。新会话/harness 实际加载 UNVERIFIED；未改编辑器设置 |
| Open Design 0.24.1，本地桌面/daemon CLI | 原生 `appConfig.customInstructions`，未写入 | BLOCKED | 内置 `od config get/set customInstructions` 入口已确认；只读访问时 daemon 不可用，退出 1，未启动服务、未改混合配置。准备好正文，待用户打开应用后接续 |
| MiniMax Design 4.0.4，@hilo/desktop | 未确认持久全局指令入口，未写入 | UNVERIFIED | 本机第一方安装代码中未确认 AGENTS/SOUL/customInstructions 等入口，不能推断它会读取 MiniMax Code 的 `.minimax/AGENTS.md`。清单提供新任务粘贴方案；该方案不是永久部署 |

补充发现：CC Switch 4.0.15、LM Studio 0.4.25+1 为切换/模型服务辅助软件，本次无 Agent 指令正文可部署，未动其配置。Gemini CLI 未发现且 `.gemini` 不存在，未创建目录或安装。OpenHuman 等未在本轮已检查安装入口发现，不宣称整机不存在；便携版、任意自定义盘路径、其他系统环境需要另按精确路径接续。VS Code 扩展列表命令未返回条目，但安装资源中确有内置 Copilot，故按内置版本适配，未把空列表误判为没有 Agent。

## 五个项目如何融合

五个项目均已写入上述两个原生项目规则文件：

1. `D:/All projects/WORK-LAB`
2. `D:/All projects/ASTRYN`
3. `D:/All projects/DESIGN-LAB`
4. `D:/All projects/Obsidian-Assistance`
5. `D:/All projects/OS External Configuration`

每个新增文件只有通用核心和一段本项目衔接要求：执行前读该项目已有根 AGENTS.md，再遵循其中指向的当前 Authority 与作用域；缺失时如实报告。没有新建第二任务账本，没有把 WORK-LAB 的阶段、目录、部署制度或历史授权传播给其他项目。现存 WORK-LAB、ASTRYN、DESIGN-LAB 的根 AGENTS/Authority 摘要全部保持一致；其他两项目原本未发现根规则，没有替其杜撰 Authority。这里完成的是通用规则与现有项目合同的接入，未代替各项目进行全文历史治理。

各项目在执行过程中有其他并发改动，最终 Git dirty 数量不能归属为本任务成果。证据只认本任务声明的规则写入集和 WORK-LAB 适配源码；不重置、不提交、不覆盖其他写者的业务文件。原根规则回读见 [project-rule-readback.json](C:/Users/ALEX/AgentRules/evidence/project-rule-readback.json)。

## 旧同步源已衔接

WORK-LAB 的旧 Codex/Hermes 投影会从另一份 YAML/软件扩展重新生成全局正文，包含将 `.project-local` 等项目约束扩展到全部项目的语句。仅改用户文件会在以后同步时回流，因此完成以下最小源衔接：

- 新建 `D:/All projects/WORK-LAB/config/universal-agent/AGENT_CORE.md` 和 `source.json`，保存母版的精确部署副本、外部来源和校验摘要。该副本是发布产物；修改流程仍从 AgentRules 母版开始。
- 两个既有 renderer 从校验副本生成通用正文。Hermes extension 只保留原生 persona 和四条软件补充；Codex extension 移除已被母版替代的旧 prose。
- `config/global-agent-policy.yaml` 标明其现有 typed machine-control/coverage 兼容职责，保留原机器字段和防护，不再作为全局自然语言母版。本次没有据此对权限或 sandbox 进行应用。
- Codex 既有 `_render_guidance` 对外层已有的相同母版段去重后归入受管区段，保留其他用户正文；遇到不一致母版拒绝覆盖。新回归覆盖漂移、保留、冲突拒绝和幂等。
- Hermes 同步器与共享 typed-policy 读取器增加原生 `hermes_yaml` 兼容回退：本机 Hermes Python 使用该 facade，缺少 PyYAML；没有安装依赖或绕过原有发布 guard。
- Hermes 经原生 plan/adoption/backup/publish/readback 发布时只选择 SOUL，其他 20 个受管资产摘要及既有 suspension 选择保持不变；配置 YAML 没有整文件复制。`config/skill-provenance.yaml` 经过原生同步流程，Git 未出现该文件改动。

现有 native-config/capability 合同在剔除说明性正文后逐项比较保持一致，见 `evidence/native-contract-preservation.json`。没有将本次规则写入泛化为 Adapter 的全业务托管能力，也没有改 adapter-registry 的 apply_supported。

执行期间 WORK-LAB HEAD 从 `6be44584241e7507b8c9f2b81fddd99de7580acc` 变为 `b5b3a3190e725cf6737372ee7e4f73f12fac584b`，origin/main 仍为前者；这是并发工作区状态，本任务没有发起提交。检查对象为本任务文件的实际摘要与带未提交改动的本地树，不能声明 exact-SHA CI。最终上下文见 `evidence/final-checks.json`。

以上同步实现与投影测试为本机局部回归，51/51 PASS；没有运行或宣称完整产品质量门、CI、提交或发布。修改清单、前后摘要和源码备份见 [source-convergence.json](C:/Users/ALEX/AgentRules/evidence/source-convergence.json)。

## 证据与备份

- [expanded-verification.json](C:/Users/ALEX/AgentRules/evidence/expanded-verification.json)：159 项，声明文件、备份、根规则保持、幂等、诊断，全部 PASS。
- [verification.json](C:/Users/ALEX/AgentRules/evidence/verification.json)：28 项，原包、初始两入口、任务启动文本和交付文件检查。
- [source-convergence-tests.json](C:/Users/ALEX/AgentRules/evidence/source-convergence-tests.json)：51 项本地同步/投影回归。
- 原生诊断：[Codex](C:/Users/ALEX/AgentRules/evidence/codex-context-check.json)、[Hermes](C:/Users/ALEX/AgentRules/evidence/hermes-native-loader.json)、[DSH](C:/Users/ALEX/AgentRules/evidence/dsh-native-loader.json)、[MiniMax Code](C:/Users/ALEX/AgentRules/evidence/minimax-native-loader.json)。仅保存结果计数，没有保存完整上下文。
- 原始 Codex/Claude 备份：`backups/20261023-224944`。
- 第一批扩展入口及 WorkBuddy 原文：`backups/20261023-231705-422131`，以 `expanded-deployment-phase1.json` 识别最初不存在的文件。
- Qoder/MiniMax Code/CodeBuddy IDE 扩展：`backups/20261023-232612-606118`，收据 `expanded-deployment-phase2.json`。
- 最后 VS Code 扩展及当前各入口快照：`backups/20261023-234051-365419`，收据 `expanded-deployment.json`。此批许多文件为 NOOP，最早原文仍在先前备份；不能拿最新快照冒充首次部署前内容。
- Hermes 源/原 live SOUL 备份：`backups/hermes-20261023-232124`；受管 state 备份：`backups/hermes-state-20261023-232235`。
- renderer/同步器/测试源衔接前备份：`backups/source-convergence-20261023-233429`。
- 上版报告已保存到 `backups/reports-20261023-234330`，本文件取代其旧状态。

所有备份目录均位于 `C:/Users/ALEX/AgentRules`；manifest 记录原先不存在、原始摘要、前后摘要和具体文件。原始工作流五模块保持按需，`task-starters/01.md` 至 `05.md` 提供可复制启动文本；`paste/CORE_FULL.txt` 为全文，`CORE_COMPACT_1500.txt` 为 1500 字符限制用的明确精简版。本轮本机入口均容纳全文，没有部署精简版。

回退必须先核对 live 摘要与对应 after_sha256。相同才恢复原文件；不同则合并撤销本任务区段，保留后续变化。首次不存在的文件只能按具体清单审核后撤销，不能清空父目录。Hermes 需通过现有受管流程协调源/live/baseline，不可单独覆盖 SOUL 再声称基线正常。没有执行回退或删除。

## 官方入口依据

实际安装版原生实现与官方入口共同核对；在线文档可能描述更新版本，差异已在上表标明。

- [Codex AGENTS.md](https://learn.chatgpt.com/docs/agent-configuration/agents-md)、[Claude Code memory](https://code.claude.com/docs/en/memory)、[Claude personalization](https://support.claude.com/en/articles/10185728-understanding-claude-s-personalization-features)。
- [Cursor Rules](https://cursor.com/docs/rules)、[VS Code custom instructions](https://code.visualstudio.com/docs/agent-customization/custom-instructions)。VS Code 还核对了本机 `e4c7e7b1d6/resources/app/out/vs/workbench/workbench.desktop.main.js` 的默认 instruction 目录和内置 Copilot package.json。
- [Hermes SOUL](https://hermes-agent.nousresearch.com/docs/guides/use-soul-with-hermes)、[DeepSeek Harness 官方仓库](https://github.com/deepseek-ai/deepseek-harness)。Windows Hermes home、DSH 全局入口采用本机已安装解析器，未硬套其他 OS 路径。
- [CodeBuddy CLI 目录](https://www.codebuddy.cn/docs/cli/codebuddy-dir)、[CodeBuddy IDE Rules](https://www.codebuddy.cn/docs/ide/User-guide/Rules)、[WorkBuddy Project](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Project)。WorkBuddy SOUL 支持另由安装包的 IdentityCollector 核实。
- [TRAE Work rules](https://docs.trae.cn/work_rules)、[Qoder CLI 配置范围](https://docs.qoder.com/cli/config-scope)。本机 TRAE 旧式单文件兼容、Qoder CN `.qoder-cn` 名称由相应已安装代码核实。
- [MiniMax Code 官方仓库](https://github.com/MiniMax-AI/minimax-code)、[MiniMax 下载](https://agent.minimax.io/download)。Desktop Code 的 native GlobalInstructions 不等同于公共 CLI 版本或 MiniMax Design。
- [Open Design 官方设置介绍](https://open-design.ai/tutorials/open-design-free-open-source-alternative-code-a-program/)。内置 daemon CLI 的 `config get/set` 在安装资源中确认，只读调用未连通。

## 诊断事件

一次 Hermes 环境诊断子进程意外将继承的 `STITCH_API_KEY` 明文回显到本次工具日志。已停止使用该诊断命令；未将密钥值复制进报告、备份或其他交付文件，也未擅自修改鉴权。**建议用户在原服务端轮换该密钥**。此处只记录变量位置/风险类型，不再呈现其值。后续诊断已改为捕获原始输出、只输出允许的布尔/摘要字段。

## 原生规则写入集（21 个文件）

| 路径 | 当前 SHA-256 |
| --- | --- |
| `C:/Users/ALEX/.codex/AGENTS.md` | `d0d627e135fa0cf93c3e32fccba5c5cd11a37aaaa49f0a521c76b5152483fd65` |
| `C:/Users/ALEX/.claude/CLAUDE.md` | `06e75f8095a8620691fd6d46826eda70109b38797ba5ba206d48b3fc9d5f3158` |
| `C:/Users/ALEX/.codebuddy/CODEBUDDY.md` | `d1248fde2b909951e8a69b2ad390b3389aa3694c692fef96f6e2e178e4e4e8ea` |
| `C:/Users/ALEX/.dsh/AGENTS.md` | `d1248fde2b909951e8a69b2ad390b3389aa3694c692fef96f6e2e178e4e4e8ea` |
| `C:/Users/ALEX/.trae-cn/user_rules.md` | `d1248fde2b909951e8a69b2ad390b3389aa3694c692fef96f6e2e178e4e4e8ea` |
| `C:/Users/ALEX/.qoder-cn/AGENTS.md` | `d1248fde2b909951e8a69b2ad390b3389aa3694c692fef96f6e2e178e4e4e8ea` |
| `C:/Users/ALEX/.minimax/AGENTS.md` | `d1248fde2b909951e8a69b2ad390b3389aa3694c692fef96f6e2e178e4e4e8ea` |
| `C:/Users/ALEX/.copilot/instructions/universal-agent-core.instructions.md` | `e46cbb3274d35dd51d66bca77ae7d2b965e3363befb1bbbdb894b948006f52c9` |
| `C:/Users/ALEX/.workbuddy/SOUL.md` | `12e46e2ade71ccd252df9b2423ad6fbca23e146153dca3ded36a7cc8fa2b87ec` |
| `C:/Users/ALEX/.workbuddy/user-eb9bc859-604d-46e2-84bf-6b1cef94d2c3-personal/SOUL.md` | `12e46e2ade71ccd252df9b2423ad6fbca23e146153dca3ded36a7cc8fa2b87ec` |
| `D:/All projects/WORK-LAB/.cursor/rules/universal-agent-core.mdc` | `13c275506e946cc3df2e2a30250454ec64a88046c5b04ad2ffaeca601b692efe` |
| `D:/All projects/WORK-LAB/.codebuddy/rules/universal-agent-core/RULE.mdc` | `20c42724e2840e557fa61f1695921ed8449928c50b62f5e15bb692f2ba62ed01` |
| `D:/All projects/ASTRYN/.cursor/rules/universal-agent-core.mdc` | `13c275506e946cc3df2e2a30250454ec64a88046c5b04ad2ffaeca601b692efe` |
| `D:/All projects/ASTRYN/.codebuddy/rules/universal-agent-core/RULE.mdc` | `20c42724e2840e557fa61f1695921ed8449928c50b62f5e15bb692f2ba62ed01` |
| `D:/All projects/DESIGN-LAB/.cursor/rules/universal-agent-core.mdc` | `13c275506e946cc3df2e2a30250454ec64a88046c5b04ad2ffaeca601b692efe` |
| `D:/All projects/DESIGN-LAB/.codebuddy/rules/universal-agent-core/RULE.mdc` | `20c42724e2840e557fa61f1695921ed8449928c50b62f5e15bb692f2ba62ed01` |
| `D:/All projects/Obsidian-Assistance/.cursor/rules/universal-agent-core.mdc` | `13c275506e946cc3df2e2a30250454ec64a88046c5b04ad2ffaeca601b692efe` |
| `D:/All projects/Obsidian-Assistance/.codebuddy/rules/universal-agent-core/RULE.mdc` | `20c42724e2840e557fa61f1695921ed8449928c50b62f5e15bb692f2ba62ed01` |
| `D:/All projects/OS External Configuration/.cursor/rules/universal-agent-core.mdc` | `13c275506e946cc3df2e2a30250454ec64a88046c5b04ad2ffaeca601b692efe` |
| `D:/All projects/OS External Configuration/.codebuddy/rules/universal-agent-core/RULE.mdc` | `20c42724e2840e557fa61f1695921ed8449928c50b62f5e15bb692f2ba62ed01` |
| `C:/Users/ALEX/AppData/Local/hermes/SOUL.md` | `2f4fccc4d6c72c3110b65c8fbf40b75365ee4374fd4a950f661f876ca2a38471` |
