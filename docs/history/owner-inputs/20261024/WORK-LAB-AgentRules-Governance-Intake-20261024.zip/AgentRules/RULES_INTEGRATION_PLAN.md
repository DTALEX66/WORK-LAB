# 全局规则与各项目规则融合：实施记录

更新时间：2026-10-23。此文件记录本次规则任务；各项目的当前任务仍由其原有 Authority/账本管理。

## 已采用的四层结构

| 层 | 归属 | 本轮实现 | 更新原则 |
| --- | --- | --- | --- |
| 通用核心 | 用户 | `C:/Users/ALEX/AgentRules/AGENT_CORE.md` 1.0.0，14 条跨软件协作规范 | 只有此处编辑通用语义；部署入口保存可见来源/版本/摘要 |
| 软件适配 | 每个软件/实际模式 | 原生 AGENTS、CLAUDE、CODEBUDDY、SOUL、user_rules、MDC、instructions.md 等分别适配 | 核对安装版与官方入口；软件 persona 与专属补充保留，模型/鉴权/权限保持原所有权 |
| 项目合同 | 每个项目 | 五项目分别增加 Cursor/CodeBuddy 原生 Always 规则，转入本项目已有 AGENTS/Authority | 项目阶段、路径、数据目录、授权与历史不跨项目传播；现有根规则原文保持 |
| 当前任务和工作流 | 当前任务 | 五份 `task-starters/01.md` 至 `05.md`，引用 WORKFLOW_MODULES 对应正文 | 任务目标、输入、授权、交付分别声明；工作流按需，临时状态不进入通用核心 |

官方/平台指令层级保持不变。通用规则提供稳定默认值，具体项目合同限定本项目做法，当前明确用户决定指导本次工作；外部文件和旧交接不能自行扩张授权。

## 实际覆盖

已写入 21 个原生规则文件，产品覆盖 Codex、Claude 的 Code 候选、Hermes、DSH、CodeBuddy、Cursor、WorkBuddy、TRAE CN、Qoder CN、MiniMax Code、VS Code Copilot。11 个用户级文件和五项目各两个项目级文件。精确清单及摘要在 DEPLOYMENT_REPORT，不用“所有软件读取 AGENTS”概括。

五项目为 WORK-LAB、ASTRYN、DESIGN-LAB、Obsidian-Assistance、OS External Configuration。它们是本轮在 `D:/All projects` 一级目录确认的全部非 AAOS Git 项目。其他资料/模型/归档目录未被当成开发项目写入。AAOS 只生成规则修复交接，不写其项目。

项目融合采取短衔接而非复制历史：先读本项目已有 AGENTS，再按其当前 Authority/作用域读取。所有现存根 AGENTS/Authority 摘要保持；没有为缺少 Authority 的项目编造一份，没有启动冻结产品任务。

## 原有规则的实际合并

- Codex：用全文母版替代已被覆盖的同义通用段，保留用户级文件的清楚入口；原文备份可回退。
- Claude：完整母版加原有有效 Code 专属补充；普通 Chat 的账户规则需要独立界面配置，不能据文件存在宣称覆盖。
- Hermes：保留已安装 persona，加母版和少量软件补充；通过既有受管同步器发布，未整包推广混合所有权配置。
- WorkBuddy：保留两个现存 SOUL 的原生 persona/frontmatter，加用户母版。其他账户未扫描，普通云端模式未假定继承。
- 新建全局入口：CodeBuddy CLI、DSH、TRAE、Qoder CN、MiniMax Code、VS Code Copilot。文件名由产品安装实现和官方机制决定。
- Cursor 和 CodeBuddy IDE：在五项目使用各自原生格式，全文核心一次；仅增加本项目规则衔接说明。

## 防止下次同步回流旧规则

WORK-LAB 旧 YAML/extension 以前也是人类正文来源，与用户指定母版形成两套维护点。已改为：

`AgentRules/AGENT_CORE.md → 受审查的 config/universal-agent 快照与摘要 → 既有 Codex/Hermes renderer → 原生文件 → 回读`。

快照是可审查的发布材料，不能独立编辑成第二母版；摘要不匹配即拒绝渲染。软件 extension 只保留原生 persona/补充。旧 YAML 保留 typed machine-control/coverage 合同职责，本次没有改变或应用权限字段。

Codex 同步器对相同外层母版去重，保留用户其他正文；不同母版报冲突，不静默覆盖。Hermes renderer 精确复现已审查 SOUL；同步器和共享读取器均兼容其原生 hermes_yaml 环境。51 项回归通过，包括快照漂移拒绝、去重/用户正文保留、原有 guard 和幂等控制。没有新建后台同步、插件平台或任务账本。

## 仍需完成的界面与验证

Open Design 的原生 daemon CLI 已定位，但服务当前不在线，写入 BLOCKED；MiniMax Design 的持久入口未确认，只提供明确每任务粘贴方案。Cursor 的项目外 User Rules、Claude 普通 Chat、其他账户/云端等按实际模式单独设置。具体动作见 MANUAL_STEPS。

4 个原生无模型诊断 PASS 与新会话/行为验收是不同证据。所有真实新 Agent 会话仍 UNVERIFIED，行为 NOT_EXECUTED；不会用文件摘要、规则自述或本地测试代替它们。

## 后续项目扩展

新项目先确认 Git 根和当前有效规则，检查目标原生文件是否已有内容，备份后合并母版，不复制其他项目进度。已被用户全局完整覆盖的同一软件通常无需再复制通用核心；仅在软件不提供可用用户全局入口时采用项目适配。需要从项目副本转到全局 UI 时，先验证全局，再按已部署摘要撤销本任务副本，保留项目合同。

软件升级后只核对相关入口、加载和长度，不自动升级、改模型或扩大权限。保留现有账户和用户选择。每次结果分开记录：已写入、原生诊断、全新会话加载、行为验收，以及未覆盖的真实模式。
