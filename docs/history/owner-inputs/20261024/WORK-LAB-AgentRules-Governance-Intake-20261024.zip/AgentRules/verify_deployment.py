"""Read-only checks of explicitly deployed files and this task's artifacts."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent
checks = []
def sha(data):
    return hashlib.sha256(data).hexdigest()
def check(name, ok):
    checks.append({'check': name, 'status': 'PASS' if ok else 'FAIL'})

for line in (root/'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
    expected, name = line.split(maxsplit=1)
    check('source:'+name, sha((root/name).read_bytes()) == expected)
core = (root/'AGENT_CORE.md').read_text(encoding='utf-8-sig').strip()
receipt = json.loads((root/'evidence'/'deployment.json').read_text(encoding='utf-8'))
allowed = {r'C:\Users\ALEX\.codex\AGENTS.md', r'C:\Users\ALEX\.claude\CLAUDE.md'}
for item in receipt['files']:
    assert item['path'] in allowed
    p = Path(item['path'])
    assert not p.is_symlink() and not p.is_junction()
    data = p.read_bytes()
    text = data.decode('utf-8')
    check(p.parent.name+':after_hash', sha(data) == item['after_sha256'])
    check(p.parent.name+':original_backup', sha(Path(item['backup']).read_bytes()) == item['before_sha256'])
    check(p.parent.name+':core_once', text.count(core) == 1)
    check(p.parent.name+':managed_markers', text.count('## BEGIN UNIVERSAL_AGENT_CORE v1.0.0') == 1 and text.count('## END UNIVERSAL_AGENT_CORE v1.0.0') == 1)
check('codex_override_still_absent', not Path(r'C:\Users\ALEX\.codex\AGENTS.override.md').exists())
check('gemini_directory_not_created', not Path(r'C:\Users\ALEX\.gemini').exists())
check('paste_full_core', (root/'paste'/'CORE_FULL.txt').read_text(encoding='utf-8').strip() == core)
check('compact_length', len((root/'paste'/'CORE_COMPACT_1500.txt').read_text(encoding='utf-8')) <= 1500)
modules = (root/'WORKFLOW_MODULES.md').read_text(encoding='utf-8-sig')
for i, m in enumerate(re.finditer(r'^## (.+)\n([\s\S]*?)(?=^## |\Z)', modules, re.M), 1):
    text = (root/'task-starters'/f'{i:02d}.md').read_text(encoding='utf-8')
    check(f'module:{i:02d}:exact_body', m.group(2).strip() in text)
check('modules_five', i == 5)
context = json.loads((root/'evidence'/'codex-context-check.json').read_text(encoding='utf-8'))
check('codex_offline_context', context['exit_code'] == 0 and context['core_exact_occurrences'] == 1 and context['status'] == 'PASS')
for name in ['DEPLOYMENT_REPORT.md','MANUAL_STEPS.md','RULES_INTEGRATION_PLAN.md','AAOS_RULES_REPAIR_HANDOFF.md']:
    text = (root/name).read_text(encoding='utf-8')
    check('delivery:'+name, len(text) > 500 and '\ufffd' not in text)
result = {'checks': checks, 'total': len(checks), 'failed': sum(c['status']=='FAIL' for c in checks),
          'behavior': 'NOT_EXECUTED', 'other_software_runtime': 'UNVERIFIED'}
(root/'evidence'/'verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(1 if result['failed'] else 0)
