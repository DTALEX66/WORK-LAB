"""SOUL-only use of WORK-LAB's existing guarded synchronizer, with native YAML."""
import contextlib
import datetime as dt
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import site
import sys

ROOT=Path(__file__).resolve().parent
REPO=Path(r'D:\All projects\WORK-LAB')
HOME=Path(r'C:\Users\ALEX\AppData\Local\hermes')
site.addsitedir(r'C:\Users\ALEX\AppData\Local\hermes\installs\370ed2771dda76e8\environments\6fde91fc54de4053a674d94f8188aa65\venv\Lib\site-packages')
sys.path.insert(0,str(HOME/'hermes-agent'))
spec=importlib.util.spec_from_file_location('hsync',REPO/'integrations/executors/hermes/sync_hermes_workflow_assets.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def main():
    state=m.asset_baseline.load_state(HOME)
    original_suspended=state.get('suspended',[])
    inputs=m.managed_guard_inputs(REPO,HOME)
    suspended=[t for t in inputs if t!='SOUL.md']
    plan=m.build_action_plan(REPO,HOME,suspended=suspended)
    (ROOT/'evidence/hermes-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({'guard':[(r['target'],r['verdict']) for r in plan['guard']['rows']], 'config':plan['config']['operation']},ensure_ascii=False))
    if '--apply' not in sys.argv:return
    b=ROOT/'backups'/('hermes-state-'+dt.datetime.now().strftime('%Y%m%d-%H%M%S'));b.mkdir()
    baseline=m.asset_baseline.state_path(HOME)
    if baseline.exists():(b/baseline.name).write_bytes(baseline.read_bytes())
    soul_full_sha=hashlib.sha256((HOME/'SOUL.md').read_bytes()).hexdigest()
    # The existing guard's established asset digest format is 16 hex characters.
    soul_sha=inputs['SOUL.md']['live_sha256']
    assert soul_full_sha.startswith(soul_sha)
    # Named, reviewed adoption is separate from publish; no wildcard adoption.
    m.adopt_baselines(REPO,HOME,reviewed={'SOUL.md':soul_sha},operator='user-authorized AgentRules deployment 2026-10-23')
    approved=m.build_action_plan(REPO,HOME,suspended=suspended)
    assert approved['guard']['will_write']==['SOUL.md'],approved['guard']['will_write']
    capture=io.StringIO()
    try:
        with contextlib.redirect_stdout(capture):
            m.deploy_portable(REPO,HOME,apply=True,include_config=False,suspended=suspended,run_id='agent-core-rules-20261023')
    finally:
        # --suspend is used only to narrow this operation. Preserve the prior
        # future-management selection; keep the new, frozen SOUL digest.
        current=m.asset_baseline.load_state(HOME)
        current['suspended']=original_suspended
        m.asset_baseline.save_state(HOME,current,run_id='agent-core-rules-20261023')
    m.verify_action_plan_readback(approved,REPO,HOME,skip=suspended)
    assert (HOME/'SOUL.md').read_bytes()==(REPO/'config/SOUL.md').read_bytes()
    again=m.build_action_plan(REPO,HOME,suspended=suspended)
    assert not again['guard']['will_write']
    assert m.asset_baseline.load_state(HOME).get('suspended',[])==original_suspended
    # Managed digests prove all non-SOUL assets were preserved.
    after=m.managed_guard_inputs(REPO,HOME)
    assert all(inputs[t]['live_sha256']==after[t]['live_sha256'] for t in suspended)
    receipt={'write':'PASS','native_sync_readback':'PASS','idempotence':'PASS','only_written_asset':'SOUL.md',
             'after_sha256':hashlib.sha256((HOME/'SOUL.md').read_bytes()).hexdigest(),
             'source':str(REPO/'config/SOUL.md'),'target':str(HOME/'SOUL.md'),
             'all_other_managed_asset_digests_preserved':True,'persistent_suspension_preserved':True,
             'mixed_config':'NOT_READ_NOT_WRITTEN','startup_load':'UNVERIFIED','behavior':'NOT_EXECUTED',
             'native_state_backup':str(b)}
    (ROOT/'evidence/hermes-deployment.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(receipt,ensure_ascii=False))

if __name__=='__main__':main()
