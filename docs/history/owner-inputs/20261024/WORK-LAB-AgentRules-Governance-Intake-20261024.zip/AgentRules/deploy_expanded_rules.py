"""Reviewed rules-only deployment. No model calls, settings or private-state access."""
from pathlib import Path
import argparse
import datetime as dt
import difflib
import hashlib
import json
import os
import re

ROOT = Path(__file__).resolve().parent
MASTER = ROOT / 'AGENT_CORE.md'
EXPECTED_MASTER = 'e180ea6cff9cceba7009cfc717debcf3de335b911c65c9265cb744d704b7b38a'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def safe(path):
    for part in [path, *path.parents]:
        if part.drive.upper() in ('E:', 'F:') or part.is_symlink() or part.is_junction():
            raise RuntimeError('Unsafe path: ' + str(part))
    if path.exists() and path.stat().st_nlink > 1:
        raise RuntimeError('Hard-linked target: ' + str(path))
    if 'archeaxis' in str(path).lower():
        raise RuntimeError('AAOS is explicitly excluded')

def screen(text):
    patterns = [r'-----BEGIN (?:[A-Z ]+)?PRIVATE KEY-----',
                r'\b(?:sk|ghp|gho|github_pat|xoxb|xoxp)[_-][A-Za-z0-9_-]{16,}',
                r'(?i)(?:api[_-]?key|access[_-]?token|client[_-]?secret|password)\s*[:=]\s*[\x22\x27]?[A-Za-z0-9/+_=.-]{12,}']
    if any(re.search(p, text) for p in patterns):
        raise RuntimeError('Suspected credential: no backup or write')

def core_block():
    data = MASTER.read_bytes()
    assert sha(data) == EXPECTED_MASTER
    return ('## BEGIN UNIVERSAL_AGENT_CORE v1.0.0\n\n'
            f'来源：{MASTER}\n母版版本：1.0.0；SHA-256：{sha(data)}\n\n'
            + data.decode('utf-8-sig').strip()
            + '\n\n## END UNIVERSAL_AGENT_CORE v1.0.0\n')

def desired():
    home = Path(r'C:\Users\ALEX')
    block = core_block()
    flow = '\n工作流仅在相关任务中按需使用 C:\\Users\\ALEX\\AgentRules\\WORKFLOW_MODULES.md 的对应模块；不要一次加载全部模块。\n'
    rows = []
    for software, path in [
        ('CodeBuddy Code user rules', home/'.codebuddy/CODEBUDDY.md'),
        ('DSH user rules', home/'.dsh/AGENTS.md'),
        ('TRAE CN compatible user rules', home/'.trae-cn/user_rules.md'),
        ('Qoder CN native runtime user rules', home/'.qoder-cn/AGENTS.md'),
        ('MiniMax Code local-runtime-v2 global instructions', home/'.minimax/AGENTS.md'),
    ]:
        assert path.parent.is_dir(), str(path.parent)
        old = path.read_text(encoding='utf-8-sig') if path.exists() else ''
        screen(old)
        if 'BEGIN UNIVERSAL_AGENT_CORE' in old:
            new = re.sub(r'## BEGIN UNIVERSAL_AGENT_CORE v[^\n]+[\s\S]*?## END UNIVERSAL_AGENT_CORE v[^\n]+\n?', lambda _: block, old, count=1)
        elif old.strip():
            new = '# 通用协作规则\n\n' + block + flow + '\n## 保留的原有软件规则\n\n' + old
        else:
            new = '# 用户级 Agent 规则\n\n' + block + flow
        rows.append((software, path, new))

    vscode_path = home/'.copilot/instructions/universal-agent-core.instructions.md'
    vscode_text = ('---\nname: Universal Agent Core\ndescription: Universal collaboration defaults for every task\napplyTo: "**"\n---\n\n'
                   + block + flow)
    if vscode_path.exists():
        old = vscode_path.read_text(encoding='utf-8-sig');screen(old)
        if old != vscode_text:
            raise RuntimeError('Existing Copilot rule differs: review before overwrite')
    rows.append(('VS Code Copilot user instructions', vscode_path, vscode_text))

    for path in [home/'.workbuddy/SOUL.md', home/'.workbuddy/user-eb9bc859-604d-46e2-84bf-6b1cef94d2c3-personal/SOUL.md']:
        assert path.is_file()
        old = path.read_text(encoding='utf-8-sig')
        screen(old)
        if 'BEGIN UNIVERSAL_AGENT_CORE' in old:
            new = re.sub(r'## BEGIN UNIVERSAL_AGENT_CORE v[^\n]+[\s\S]*?## END UNIVERSAL_AGENT_CORE v[^\n]+\n?', lambda _: block, old, count=1)
        else:
            # Preserve the vendor's persona template/frontmatter and append visible rules.
            new = old.rstrip() + '\n\n' + block + flow + '\n本母版段由用户管理，不自行改写；原有个性与记忆维护说明不扩大本次任务授权。\n'
        assert len(new) < 10000, 'Installed WorkBuddy SoulContent budget'
        rows.append(('WorkBuddy persona rules', path, new))

    projects = ['WORK-LAB','ASTRYN','DESIGN-LAB','Obsidian-Assistance','OS External Configuration']
    for name in projects:
        project = Path(r'D:\All projects')/name
        assert (project/'.git').exists()
        path = project/'.cursor/rules/universal-agent-core.mdc'
        # Only the core is copied; project state and authorization remain in their own authority.
        project_note = ('\n## 当前项目规则衔接\n\n'
                        '这份文件只提供通用协作默认值，不宣布项目阶段或授权产品开发。'
                        '在当前项目执行任务前，读取项目根目录已有的 AGENTS.md，以及其中指定的当前 Authority 和作用域规则；'
                        '路径不存在时如实说明，不搜索或套用其他项目的合同。'
                        '项目规则只在其项目内生效；同一母版已由软件全局提供时不重复解释或叠加工作流程。\n')
        new = '---\ndescription: Universal collaboration core 1.0.0\nglobs: \nalwaysApply: true\n---\n\n' + block + project_note
        if path.exists():
            old = path.read_text(encoding='utf-8-sig'); screen(old)
            if 'BEGIN UNIVERSAL_AGENT_CORE' not in old:
                raise RuntimeError('Unowned project rule: ' + str(path))
        rows.append(('Cursor project rules: '+name, path, new))
        cb_path = project/'.codebuddy/rules/universal-agent-core/RULE.mdc'
        if cb_path.exists():
            cb_old = cb_path.read_text(encoding='utf-8-sig');screen(cb_old)
            if 'BEGIN UNIVERSAL_AGENT_CORE' not in cb_old:
                raise RuntimeError('Unowned CodeBuddy project rule: '+str(cb_path))
        cb_new = ('---\ndescription: Universal collaboration core 1.0.0\nalwaysApply: true\nenabled: true\n---\n\n'
                  + block + project_note)
        rows.append(('CodeBuddy IDE project rules: '+name, cb_path, cb_new))
    return rows

def plan():
    files = []
    for software, path, text in desired():
        safe(path); screen(text)
        old = path.read_bytes() if path.exists() else None
        if old is not None: screen(old.decode('utf-8-sig'))
        new = text.encode('utf-8')
        files.append({'software':software,'path':str(path),'existed_before':old is not None,
                      'before_sha256':sha(old) if old is not None else None,
                      'after_sha256':sha(new),'after_bytes':len(new),'operation':'NOOP' if old==new else 'WRITE'})
    obj = {'master_sha256':EXPECTED_MASTER,'authorization':'Latest user: execute all except AAOS; rules only', 'files':files}
    obj['plan_digest'] = sha(json.dumps(obj,ensure_ascii=False,sort_keys=True).encode())
    return obj

def main():
    p = argparse.ArgumentParser();p.add_argument('--apply',action='store_true');p.add_argument('--plan-digest');args=p.parse_args()
    obj = plan()
    (ROOT/'evidence').mkdir(exist_ok=True)
    if not args.apply:
        (ROOT/'evidence/expanded-plan.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(obj,ensure_ascii=False,indent=2));return
    assert args.plan_digest == obj['plan_digest'], 'Plan changed since review'
    stamp = dt.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup = ROOT/'backups'/stamp;backup.mkdir(parents=True,exist_ok=False)
    obj['time'] = dt.datetime.now().astimezone().isoformat();obj['backup_root']=str(backup)
    prepared = desired()
    for i, ((software,path,text),row) in enumerate(zip(prepared,obj['files'])):
        safe(path)
        old = path.read_bytes() if path.exists() else None
        assert (sha(old) if old is not None else None)==row['before_sha256']
        new = text.encode('utf-8'); assert sha(new)==row['after_sha256']
        if old is not None:
            stat=path.stat();b=backup/f'{i:02d}-{path.name}';b.write_bytes(old)
            os.utime(b,ns=(stat.st_atime_ns,stat.st_mtime_ns));assert b.read_bytes()==old
            row['backup']=str(b);row['before_mtime_ns']=stat.st_mtime_ns
        else:row['backup']=None
        if old!=new:
            path.parent.mkdir(parents=True,exist_ok=True)
            assert (path.read_bytes() if path.exists() else None)==old
            path.write_bytes(new)
        assert path.read_bytes()==new
        assert text.count(MASTER.read_text(encoding='utf-8-sig').strip())==1
        row.update(write='PASS',startup_load='UNVERIFIED',behavior='NOT_EXECUTED')
        delta=''.join(difflib.unified_diff((old or b'').decode('utf-8-sig').splitlines(True),text.splitlines(True),fromfile=str(path)+' before',tofile=str(path)+' after'))
        (backup/f'{i:02d}.diff').write_text(delta,encoding='utf-8')
        (backup/'manifest.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'evidence/expanded-deployment.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':'PASS','targets':len(obj['files']),'backup':str(backup)},ensure_ascii=False))

if __name__ == '__main__':main()
