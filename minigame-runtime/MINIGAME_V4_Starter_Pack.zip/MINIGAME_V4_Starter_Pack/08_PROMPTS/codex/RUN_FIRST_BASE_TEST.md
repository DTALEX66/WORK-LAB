# CODEX TASK — RUN FIRST BASE TEST

选择一个 Phaser/H5 候选底座复制到 experiments/base-run-test，做最小运行测试：安装依赖、启动、显示画面、点击按钮、读取本地 JSON。
