# HERMES MEMORY UPDATE — MINIGAME V4

根目录：D:\All projects\MINIGAME。项目是单人 AI 小游戏生产系统。当前策略：Phaser/H5快速验证、Cocos商业候选、Godot/VN参考、第一内容包monitor_anomaly。
