# DEEPSEEK PROMPT — BATCH DRAFT EVENTS

批量生成30个低成本异常事件草案，每个一句话，可转成小游戏操作，有失败风险，有广告复活点，适合小红书标题。
