# QWEN PROMPT — GENERATE ANOMALY EVENTS

为异常监控室生成10个异常事件。包含 alarmCode, scene, rule, prompt, correctAction, wrongAction, feedback, anomalyLevelEffect, truthFragmentEffect。
