# CURRENT TASK

## 当前任务

建立 V4 版单人 AI 小游戏生产系统目录、规则文件、内容包协议和首个内容包骨架。

## 下一步任务

筛选 10 个开源游戏底座：

- Phaser/H5：5 个
- Cocos Creator：5 个
- Godot/VN/WebGAL：3 个参考

第一轮实际运行 3 个：

- 1 个 Phaser/Vite 模板
- 1 个 Cocos Creator 模板
- 1 个 VN/WebGAL/Godot 模板
