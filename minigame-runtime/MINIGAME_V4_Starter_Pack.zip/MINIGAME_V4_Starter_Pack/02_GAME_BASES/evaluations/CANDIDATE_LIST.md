# CANDIDATE LIST

## Phaser / H5 候选

1. supertorpe/vite-ts-phaser-starter
2. Ciriak/phaser3-typescript-boilerplate
3. smoudjs/playable-template-phaser
4. brenopolanski/phaser-es6-starter
5. rroylance/phaser-ce-npm-webpack-typescript-starter-project

## Cocos 候选

1. lewisun7/template-cocos-creator
2. 待补充：Cocos Creator 微信小游戏模板
3. 待补充：Cocos Creator 超休闲模板
4. 待补充：Cocos Creator 广告/存档模板
5. 待补充：Cocos Creator 弹窗/UI模板

## Godot / VN / WebGAL 参考

1. rakugoteam/VisualNovelKit
2. mkblumenau/godot-visual-novel-template
3. OpenWebGAL/WebGAL

注意：这些只是候选，不代表可商用，必须检查 LICENSE 和运行情况。
