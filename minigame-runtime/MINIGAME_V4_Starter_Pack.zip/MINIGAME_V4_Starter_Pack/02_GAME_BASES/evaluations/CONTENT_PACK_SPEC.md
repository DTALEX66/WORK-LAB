# CONTENT PACK SPEC

所有内容必须配置化，统一为 content-pack.json。

必填字段：packId, title, targetUser, coreMechanic, states, events, actions, feedback, adSlots, shareText, xiaohongshuHooks, platformNotes。

内容包不直接绑定某个引擎。底座负责运行，内容包负责题材和玩法配置。
