# MODEL ROUTER

ChatGPT：总规划。Codex：代码执行。CC/Claude：审查拆解。Qwen：中文内容。DeepSeek：批量草案。Hermes：记忆复盘。
