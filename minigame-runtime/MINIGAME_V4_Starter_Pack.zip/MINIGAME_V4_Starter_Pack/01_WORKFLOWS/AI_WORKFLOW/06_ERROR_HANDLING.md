# ERROR HANDLING

遇错不重构整个项目，不删除重建，先记录错误，只定位最小问题，在 SANDBOX 复现，修复前备份。
