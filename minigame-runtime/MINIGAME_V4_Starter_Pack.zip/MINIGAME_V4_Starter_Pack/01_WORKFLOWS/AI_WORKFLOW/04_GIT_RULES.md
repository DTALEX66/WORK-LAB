# GIT RULES

小步提交；每个功能一个 commit；commit 前看 diff；禁止自动 push；禁止 force push；不删除旧项目。
