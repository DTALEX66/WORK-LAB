# CODEX RULES

Codex 是唯一代码执行者。必须先读 BOOT、AGENTS、PROJECT_CONTEXT、CURRENT_TASK。禁止删除文件、接真实广告SDK、自动push、下载大量仓库、从零写完整游戏框架。
