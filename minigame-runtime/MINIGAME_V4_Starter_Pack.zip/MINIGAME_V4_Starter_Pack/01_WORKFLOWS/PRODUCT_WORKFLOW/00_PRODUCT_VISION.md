# PRODUCT VISION

目标不是做一个游戏，而是建立单人 AI 小游戏生产系统，通过 IAA 广告变现拿到第一桶金。
