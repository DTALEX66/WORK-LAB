# ROADMAP

Phase1目录/工作流/底座筛选；Phase2运行3个底座；Phase3接monitor_anomaly；Phase4做3分钟原型；Phase5内容测试；Phase6继续/砍掉/换皮。
