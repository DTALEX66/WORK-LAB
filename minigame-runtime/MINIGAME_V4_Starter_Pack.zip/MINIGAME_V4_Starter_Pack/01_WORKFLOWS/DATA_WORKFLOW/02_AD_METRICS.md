# AD METRICS

当前只做广告占位。未来指标：revive_ad_click, clue_ad_click, fake_ending_ad_click, ad_completion_rate。
