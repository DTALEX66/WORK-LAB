# EVENT TRACKING PLAN

事件：game_start, first_click, anomaly_found, wrong_action, fail, revive_click, clue_unlock_click, game_complete。
