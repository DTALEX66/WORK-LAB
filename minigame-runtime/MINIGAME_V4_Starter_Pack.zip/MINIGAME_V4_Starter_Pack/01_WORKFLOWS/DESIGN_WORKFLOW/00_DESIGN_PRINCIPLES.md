# DESIGN PRINCIPLES

当前产品方向：悬疑皮 + 超休闲机制 + 广告循环小游戏。第一款内容包：异常监控室 monitor_anomaly。
