# MINIGAME V4 Starter Pack

这是「单人 AI 小游戏生产系统」V4 启动包。

## 解压位置

建议解压到：

```text
D:\All projects\MINIGAME
```

路径中有空格，所有命令必须加英文双引号。

## 核心定位

本系统不是单个游戏项目，而是：

> 单人 AI + 开源游戏底座 + Codex 接入 + AI 内容包 + 广告循环 + 小红书/抖音引流 的小游戏生产系统。

## 当前第一阶段

1. 搭建目录和工作流
2. 筛选开源游戏底座
3. 建立 content-pack.json 内容包协议
4. 用 `monitor_anomaly` 做第一个 3 分钟原型
5. 用小红书/抖音内容测试题材
6. 根据数据决定继续、砍掉或换皮

## 第一款内容包

```text
monitor_anomaly
中文名：异常监控室
```
