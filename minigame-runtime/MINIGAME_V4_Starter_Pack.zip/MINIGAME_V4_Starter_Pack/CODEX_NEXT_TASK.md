# CODEX NEXT TASK

请在 `"D:\All projects\MINIGAME"` 中进行下一步：

筛选并记录第一批开源小游戏底座候选，不下载大量仓库，只更新候选表和评分模板。

目标：
- Phaser/H5：5 个
- Cocos Creator：5 个
- Godot/VN/WebGAL：3 个参考

输出：候选列表、初步风险、第一轮建议实际运行的 3 个底座。
